<template>
  <v-app>

    <v-app-bar
        app
        color="red"
    >
      <v-app-bar-title>
        <h3 class="text-h4 white--text">Books</h3>
      </v-app-bar-title>
    </v-app-bar>

<!--    <v-main>
&lt;!&ndash;      <router-view></router-view>&ndash;&gt;
      <h3 class="text-h4 white&#45;&#45;text">Books list</h3>
    </v-main>-->

  </v-app>
</template>