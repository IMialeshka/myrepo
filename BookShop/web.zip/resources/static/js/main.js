import Vue  from 'vue'
import App from './/pages/App.vue'
import Vuetify from './plugins/vuetify'


//import Vuetify from 'vuetify'

//Vue.use(Vuetify)

new Vue({
    el: '#app',
    Vuetify,
    render: a =>a(App)
})
